#include <ti/drivers/UART.h>
#define DISPLAY(x) UART_write(uart, &output, x);
// UART Global Variables
Char output[64];
Int bytesToSend;
// Driver Handles - Global variables
UART_Handle uart;
void initUART(void)
{
UART_Params uartParams;
// Init the driver
UART_init();
// Configure the driver
UART_Params_init(&uartParams);
uartParams.writeDataMode = UART_DATA_BINARY;
uartParams.readDataMode = UART_DATA_BINARY;
uartParams.readReturnMode = UART_RETURN_FULL;
uartParams.baudRate = 115200;
// Open the driver
uart = UART_open(CONFIG_UART_0, &uartParams);
if (uart == NULL) {
/* UART_open() failed */
while (1);
}
}
